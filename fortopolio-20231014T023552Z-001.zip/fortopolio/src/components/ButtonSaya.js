import "../styles/ButtonSaya.css"
function ButtonSaya() {
    return (
        <button type="button" class="btn
        btn-saya">Button</button>
    )
}
export default ButtonSaya