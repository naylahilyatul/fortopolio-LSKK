function AboutMe() {
    return (
        <div className="section"> 
        <div className="row align-items-center">
            <div className="col-6 text-center">
            <img 
            className="avatar"
            src="https://e7.pngegg.com/pngimages/84/165/png-clipart-united-states-avatar-organization-information-user-avatar-service-computer-wallpaper-thumbnail.png">
            </img>
            </div>
            <div className="col-6">
            <h1> About Me</h1>
            <p>
                Saya adalah nayla seorang ratu di kerajaan BRITANIA RAYA
                saya berkuasa pada abad 19, saya menjabat sebgaai ratu tercanti di dunia.
            </p>
            <p>
                Dan saya lahir dengaan bayik yang sangat comel dan saya berhasil
                memusnahkan semua musuh umat manusia, karna itu saya mempunyai julukan ratu dari segala ratu
            </p>
            <p>
                Dan saya lahir dengaan bayik yang sangat comel dan saya berhasil
                memusnahkan semua musuh umat manusia, karna itu saya mempunyai julukan ratu dari segala ratu
            </p>
            <p>
                Dan saya lahir dengaan bayik yang sangat comel dan saya berhasil
                memusnahkan semua musuh umat manusia, karna itu saya mempunyai julukan ratu dari segala ratu
            </p>
            <p>
                Dan saya lahir dengaan bayik yang sangat comel dan saya berhasil
                memusnahkan semua musuh umat manusia, karna itu saya mempunyai julukan ratu dari segala ratu
            </p>
            <p>
                Dan saya lahir dengaan bayik yang sangat comel dan saya berhasil
                memusnahkan semua musuh umat manusia, karna itu saya mempunyai julukan ratu dari segala ratu
            </p>
            </div>
        </div>
           
        </div>
    )
}
export default AboutMe;