import ButtonSaya from "./ButtonSaya";
function Intro() {
    return (
       <div className="section text-light intro">
        <div className="container text-center">
            <img 
            className="avatar"
            src="https://e7.pngegg.com/pngimages/84/165/png-clipart-united-states-avatar-organization-information-user-avatar-service-computer-wallpaper-thumbnail.png">
                
            </img>
            <h1>Nayla Hilyatul Auliyadien</h1>
            <p>Web Developer</p>
            <a href="instagram.com" className="social-media">
            <i class="bi bi-instagram"></i>
            </a>

            <a href="instagram.com" className="social-media">
            <i class="bi bi-facebook"></i>
            </a>

            <a href="instagram.com" className="social-media">
            <i class="bi bi-github"></i>
            </a>
            <div className="row">
                <div className="col">
                <ButtonSaya />
                </div>
            </div>
        </div>
       </div>
    )
}
export default Intro;